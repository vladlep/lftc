#include <stdio.h>
//#include "structs.h"

void checkProject(struct atomi *curent)
{
	printf("check project started");
}
void checkProgram(struct atomi *curent)
{
	printf("it's ok");
}

